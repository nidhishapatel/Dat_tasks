import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import warnings
warnings.filterwarnings('ignore')


class ChurnPredictor:
    def __init__(self):
        self.feature_weights = {
            'Skill Gap':           0.25,
            'Performance Deficit': 0.20,
            'Salary Below Market': 0.18,
            'Overtime Excess':     0.12,
            'Attendance Issue':    0.10,
            'Short Tenure':        0.08,
            'Promotion Delay':     0.07,
        }
        self._train_model()

    def _train_model(self):
        np.random.seed(42)
        n = 1500
        X = pd.DataFrame({
            'skill':        np.random.uniform(30, 100, n),
            'perf':         np.random.uniform(40, 100, n),
            'salary_ratio': np.random.uniform(0.6, 1.4, n),
            'overtime':     np.random.uniform(0, 30, n),
            'attendance':   np.random.uniform(60, 100, n),
            'tenure':       np.random.exponential(3, n),
            'promo_delay':  np.random.exponential(2, n),
        })
        risk = (
            (100 - X['skill'])       * 0.25 +
            (100 - X['perf'])        * 0.20 +
            (1 - X['salary_ratio'])  * 20   * 0.18 +
            np.clip(X['overtime']-8, 0, None) * 0.8 * 0.12 +
            (100 - X['attendance'])  * 0.10 +
            np.exp(-X['tenure']/3)   * 20   * 0.08 +
            (X['promo_delay'] > 2)   * 15   * 0.07
        )
        risk = np.clip(risk / 100, 0, 1)
        y = (risk > 0.5).astype(int)
        self.model = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)
        self.model.fit(X, y)

    def predict_churn(self, emp):
        skill_gap   = max(0, 100 - emp.get('skill_score', 70))
        perf_def    = max(0, 75  - emp.get('performance', 75))
        salary_b    = emp.get('salary_benchmark', 100)
        overtime    = emp.get('overtime_hours', 8)
        attendance  = emp.get('attendance_rate', 95)
        tenure      = emp.get('tenure_years', 2)
        promo_delay = max(0, 2025 - emp.get('last_promotion', 2022))
        risk  = (skill_gap / 100) * 0.25
        risk += (perf_def / 100)  * 0.20
        risk += (max(0, 100 - salary_b) / 100) * 0.18
        risk += (max(0, overtime - 10) / 20)   * 0.12
        risk += (max(0, 95 - attendance) / 20) * 0.10
        if tenure < 1:   risk += 0.08 * 0.30
        elif tenure > 5: risk += 0.08 * 0.10
        else:            risk += 0.08 * 0.15
        if promo_delay > 3 and emp.get('performance', 75) > 80:
            risk += 0.07
        prob = 1 / (1 + np.exp(-3 * (risk - 0.5)))
        return round(float(prob), 3)

    def predict_batch(self, df):
        probs  = [self.predict_churn(r.to_dict()) for _, r in df.iterrows()]
        levels = ['High' if p > 0.65 else 'Medium' if p > 0.35 else 'Low' for p in probs]
        return pd.DataFrame({'probability': probs, 'risk_level': levels})

    def explain_factors(self, emp):
        f = {}
        sg = max(0, 100 - emp.get('skill_score', 70))
        if sg > 15: f['Skill Gap'] = round(sg / 100, 3)
        pd_ = max(0, 75 - emp.get('performance', 75))
        if pd_ > 8: f['Performance Deficit'] = round(pd_ / 100, 3)
        ot = emp.get('overtime_hours', 8)
        if ot > 10: f['High Overtime'] = round((ot - 10) / 20, 3)
        sb = emp.get('salary_benchmark', 100)
        if sb < 90: f['Below Market Salary'] = round((100 - sb) / 100, 3)
        att = emp.get('attendance_rate', 95)
        if att < 90: f['Low Attendance'] = round((95 - att) / 20, 3)
        ten = emp.get('tenure_years', 2)
        if ten < 1.5: f['Low Tenure'] = round((1.5 - ten) / 1.5, 3)
        return dict(sorted(f.items(), key=lambda x: x[1], reverse=True))

    def recommend_actions(self, emp):
        acts = []
        sg = max(0, 100 - emp.get('skill_score', 70))
        if sg > 25: acts.append(f"🎓 Enroll in upskilling — close {sg:.0f}% skill gap")
        if emp.get('performance', 75) < 70: acts.append("📈 Performance improvement plan with monthly check-ins")
        if emp.get('overtime_hours', 8) > 12: acts.append("⚖️ Redistribute workload — reduce OT to <10h/week")
        if emp.get('salary_benchmark', 100) < 85: acts.append("💰 Adjust salary to market benchmark")
        if emp.get('attendance_rate', 95) < 88: acts.append("🗓️ Introduce flexible scheduling")
        if not acts:
            acts.append("✅ Quarterly career growth conversations")
            acts.append("🌟 Nominate for mentorship or stretch project")
        return acts[:4]

    def strategic_insights(self, df):
        avg  = df['churn_probability'].mean()
        high = int((df['churn_probability'] > 0.65).sum())
        med  = int(((df['churn_probability'] > 0.35) & (df['churn_probability'] <= 0.65)).sum())
        return {
            'avg_risk': float(avg), 'high_risk_count': high, 'medium_risk_count': med,
            'urgency': 'High' if avg > 0.5 else ('Medium' if avg > 0.3 else 'Low'),
            'cost_estimate': high * 52000,
            'recommendations': [
                "Conduct stay interviews with all high-risk employees within 2 weeks",
                "Review and adjust below-market compensation packages immediately",
                "Launch department-specific upskilling sprints this quarter",
                "Implement flexible work policy to reduce overtime burnout",
                "Introduce peer recognition programme to boost engagement",
            ]
        }

    def future_trends(self, df, months=6):
        cur = float(df['churn_probability'].mean())
        ml  = list(range(1, months + 1))
        return {
            'months':      ml,
            'expected':    [max(0.05, cur * (0.94 ** (i/3))) for i in range(months)],
            'optimistic':  [max(0.05, cur * (0.82 ** (i/3))) for i in range(months)],
            'pessimistic': [min(0.95, cur * (1.04 ** (i/3))) for i in range(months)],
        }

    def get_feature_importance(self):
        return self.feature_weights


class SkillGapAnalyzer:
    ROLE_SKILLS = {
        'Data Scientist':     ['Python', 'ML/AI', 'Statistics', 'SQL', 'Visualisation'],
        'ML Engineer':        ['MLOps', 'Deep Learning', 'Python', 'Cloud', 'Docker'],
        'Backend Developer':  ['API Design', 'Databases', 'Sys Design', 'Security', 'DevOps'],
        'Frontend Developer': ['React/Vue', 'CSS/UX', 'JavaScript', 'Testing', 'Performance'],
        'DevOps Engineer':    ['Kubernetes', 'CI/CD', 'Terraform', 'Monitoring', 'Security'],
        'Product Manager':    ['Roadmapping', 'Analytics', 'Stakeholders', 'Agile', 'UX'],
        'HR Generalist':      ['Recruitment', 'Emp. Relations', 'HRIS', 'Compliance', 'L&D'],
        'Financial Analyst':  ['Fin. Modelling', 'Excel/BI', 'Forecasting', 'Accounting', 'Risk'],
        'Sales Director':     ['Pipeline Mgmt', 'Negotiation', 'CRM', 'Leadership', 'Strategy'],
        'default':            ['Communication', 'Project Mgmt', 'Domain Exp.', 'Collab.', 'Analytics'],
    }
    LEARNING_PATHS = {
        'Data Scientist':     ['Advanced Python & Algorithms', 'Deep Learning (Coursera)', 'MLOps Fundamentals', 'Cloud ML Platforms'],
        'ML Engineer':        ['Kubernetes for ML', 'Model Monitoring & Drift', 'Advanced Python', 'AWS/GCP Cert.'],
        'Backend Developer':  ['System Design Patterns', 'Advanced SQL & DB Tuning', 'Security Best Practices', 'Microservices'],
        'Frontend Developer': ['React Advanced Patterns', 'Web Performance Optim.', 'Accessibility Standards', 'TypeScript'],
        'DevOps Engineer':    ['CKA (Kubernetes)', 'Terraform Advanced', 'SRE Practices', 'Security Automation'],
        'Product Manager':    ['Data-Driven Product Strategy', 'SQL for PMs', 'OKR Framework', 'User Research'],
        'HR Generalist':      ['People Analytics', 'HR Tech Platforms', 'Change Management', 'Employment Law'],
        'Sales Director':     ['Strategic Account Mgmt', 'Data-Driven Sales', 'Executive Negotiation', 'RevOps'],
        'default':            ['Role-Specific Certification', 'Leadership Essentials', 'Project Mgmt (PMP)', 'Communication'],
    }

    def analyze_skill_gap(self, emp):
        skill  = float(emp.get('skill_score', 70))
        gap    = max(0.0, 100.0 - skill)
        cat    = 'Critical' if gap > 30 else ('Moderate' if gap > 15 else 'Low')
        role   = str(emp.get('role', ''))
        skills = self.ROLE_SKILLS.get(role, self.ROLE_SKILLS['default'])
        seed   = int(skill * 137 + float(emp.get('tenure_years', 2)) * 31) % (2**31)
        rng    = np.random.default_rng(seed)
        bd     = {s: int(np.clip(skill + rng.uniform(-20, 20), 20, 100)) for s in skills}
        return {'gap_percentage': round(gap, 1), 'category': cat, 'skill_breakdown': bd}

    def analyze_batch(self, df):
        rows = [self.analyze_skill_gap(r.to_dict()) for _, r in df.iterrows()]
        return pd.DataFrame([{'gap_percentage': r['gap_percentage'], 'category': r['category']} for r in rows])

    def get_learning_path(self, emp):
        return self.LEARNING_PATHS.get(str(emp.get('role', '')), self.LEARNING_PATHS['default'])


class PromotionRecommender:
    def predict(self, emp):
        score = (emp.get('skill_score', 70)/100)*0.40 + (emp.get('performance', 75)/100)*0.40 + min(emp.get('experience', 2)/10, 1)*0.20
        return {'ready': bool(score >= 0.70), 'score': round(score * 100, 1)}

    def predict_batch(self, df):
        return pd.DataFrame([self.predict(r.to_dict()) for _, r in df.iterrows()])

    def calculate_impact(self, emp):
        risk  = emp.get('churn_probability', 0.5)
        boost = min(35, (1 - risk) * 50)
        inc   = 18 if risk > 0.5 else 12
        return {'retention_boost': round(boost, 1), 'recommended_increase': f"{inc}%",
                'timeline': 'Next quarter' if emp.get('performance', 75) > 85 else 'Next 6 months'}


class SalaryBenchmarker:
    MARKET = {
        'Data Scientist': 85000, 'ML Engineer': 120000, 'HR Generalist': 65000,
        'Product Manager': 130000, 'UX Designer': 75000, 'Backend Developer': 95000,
        'Sales Director': 140000, 'Data Engineer': 90000, 'Marketing Specialist': 70000,
        'IT Support': 65000, 'Frontend Developer': 80000, 'DevOps Engineer': 120000,
        'Financial Analyst': 75000, 'Cloud Architect': 140000, 'Business Analyst': 80000,
        'Security Engineer': 110000, 'QA Engineer': 75000, 'Technical Writer': 70000,
        'Solution Architect': 135000, 'Project Manager': 95000,
    }

    def benchmark(self, emp):
        market = self.MARKET.get(str(emp.get('role', 'General')), 80000)
        salary = emp.get('salary', 80000)
        pct    = round((salary / market) * 100, 1)
        status = 'Below Market' if pct < 85 else ('Above Market' if pct > 115 else 'At Market')
        return {'benchmark_percentage': pct, 'status': status, 'market_rate': market}

    def benchmark_batch(self, df):
        return pd.DataFrame([self.benchmark(r.to_dict()) for _, r in df.iterrows()])
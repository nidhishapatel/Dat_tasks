import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import json, base64, sys, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from models import ChurnPredictor, SkillGapAnalyzer, PromotionRecommender, SalaryBenchmarker

# ══════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title="Churn Intelligence · HR Analytics",
    page_icon="🧠", layout="wide",
    initial_sidebar_state="expanded",
)

# ══════════════════════════════════════════════════════════════════════
#  CSS
# ══════════════════════════════════════════════════════════════════════
st.markdown("""
<style>
html,body,[data-testid="stAppViewContainer"],[data-testid="stApp"]{
  background:#0b0f1a !important;color:#e2e8f0 !important;
  font-family:'Segoe UI',system-ui,sans-serif;}
[data-testid="stSidebar"]{background:#0d1117 !important;
  border-right:1px solid rgba(56,189,248,.10);}
section[data-testid="stSidebar"]>div{background:transparent;}
.block-container{padding-top:1.4rem !important;max-width:100% !important;}
[data-testid="stSlider"]>div>div>div>div{background:#38bdf8 !important;}
[data-testid="stSlider"]>div>div>div{background:rgba(56,189,248,.18) !important;}
[data-testid="stSelectbox"]>div>div,[data-testid="stMultiSelect"]>div>div{
  background:#131920 !important;border:1px solid rgba(56,189,248,.18) !important;
  color:#e2e8f0 !important;border-radius:8px !important;}
[data-testid="stMetric"]{background:#111827 !important;
  border:1px solid rgba(56,189,248,.12);border-radius:12px !important;padding:14px 18px !important;}
[data-testid="stMetricLabel"]{color:#64748b !important;font-size:11px !important;
  text-transform:uppercase;letter-spacing:1.5px;}
[data-testid="stMetricValue"]{color:#e2e8f0 !important;font-weight:800 !important;}
.stButton>button{background:linear-gradient(135deg,#38bdf8,#818cf8) !important;
  color:#000 !important;border:none !important;border-radius:10px !important;
  font-weight:800 !important;font-size:13px !important;padding:10px 22px !important;}
.stButton>button:hover{opacity:.86 !important;}
div[data-testid="stTabs"] button{background:#0d1117 !important;color:#64748b !important;
  border:none !important;font-weight:700 !important;font-size:13px !important;}
div[data-testid="stTabs"] button[aria-selected="true"]{background:#1a2336 !important;
  color:#38bdf8 !important;border-bottom:2px solid #38bdf8 !important;}
[data-testid="stExpander"]{background:#111827 !important;
  border:1px solid rgba(56,189,248,.12) !important;border-radius:10px !important;}
[data-testid="stExpander"] summary{color:#e2e8f0 !important;font-weight:700;}
[data-testid="stRadio"] label{color:#94a3b8 !important;font-size:13px !important;}
[data-testid="stRadio"] label:hover{color:#38bdf8 !important;}
.card{background:#111827;border:1px solid rgba(56,189,248,.12);
  border-radius:14px;padding:20px 22px;margin-bottom:8px;}
.kpi{background:#111827;border:1px solid rgba(56,189,248,.12);border-radius:14px;
  padding:18px 20px;position:relative;overflow:hidden;}
.kpi::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--acc,#38bdf8);}
.kpi-lbl{font-size:10px;letter-spacing:1.8px;text-transform:uppercase;color:#64748b;font-weight:700;}
.kpi-val{font-size:28px;font-weight:900;letter-spacing:-1px;margin:6px 0 2px;}
.kpi-sub{font-size:12px;color:#94a3b8;}
.gauge-card{background:#111827;border:1px solid rgba(56,189,248,.15);
  border-radius:16px;padding:24px 20px;text-align:center;}
.gauge-pct{font-size:72px;font-weight:900;letter-spacing:-4px;line-height:1;}
.gauge-badge{display:inline-block;margin-top:10px;padding:7px 20px;
  border-radius:24px;font-size:13px;font-weight:800;letter-spacing:.5px;}
.sig-row{display:flex;align-items:center;gap:10px;font-size:13px;color:#94a3b8;
  padding:7px 0;border-bottom:1px solid rgba(56,189,248,.06);}
.sig-dot{width:9px;height:9px;border-radius:50%;flex-shrink:0;}
.prog-wrap{background:#1a2336;border-radius:10px;height:8px;overflow:hidden;margin-top:5px;}
.prog-fill{height:100%;border-radius:10px;}
.fbar-wrap{background:#1a2336;border-radius:10px;height:8px;overflow:hidden;flex:1;}
.fbar-fill{height:100%;border-radius:10px;}
.sdot{display:inline-block;width:7px;height:7px;border-radius:50%;background:#34d399;
  margin-right:6px;animation:pulse 2s infinite;}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
.sec-h{font-size:22px;font-weight:900;letter-spacing:-.5px;color:#e2e8f0;margin-bottom:2px;}
.sec-s{font-size:13px;color:#64748b;margin-bottom:18px;}
.profile-box{background:#111827;border:1px solid rgba(56,189,248,.14);
  border-radius:14px;padding:22px 24px;}
.profile-box-title{font-size:14px;font-weight:800;color:#e2e8f0;margin-bottom:18px;}
.slider-lbl{font-size:10px;letter-spacing:1.6px;text-transform:uppercase;
  color:#64748b;font-weight:700;margin-bottom:-8px;}
  
      /* Header (top white bar) */
    header[data-testid="stHeader"] {
        background-color: transparent !important;
    }

    /* Remove white block behind toolbar */
    .stAppHeader {
        background-color: black !important;
    }
  
</style>
""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════
#  CHART DEFAULTS
# ══════════════════════════════════════════════════════════════════════
DARK = dict(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
            font=dict(color='#94a3b8', family='Segoe UI'),
            margin=dict(t=34, b=10, l=10, r=10),
            legend=dict(bgcolor='rgba(0,0,0,0)', font=dict(color='#94a3b8')))
AX   = dict(gridcolor='rgba(56,189,248,.07)', zerolinecolor='rgba(56,189,248,.12)',
            color='#64748b', tickfont=dict(color='#64748b'))
CLR  = ['#38bdf8','#818cf8','#f472b6','#fb923c','#34d399','#facc15','#a78bfa']

def dc(fig): fig.update_layout(**DARK); return fig

# ══════════════════════════════════════════════════════════════════════
#  MODELS  (loaded once per session)
# ══════════════════════════════════════════════════════════════════════
@st.cache_resource
def load_models():
    return ChurnPredictor(), SkillGapAnalyzer(), PromotionRecommender(), SalaryBenchmarker()

churn_m, skill_m, promo_m, salary_m = load_models()

# ══════════════════════════════════════════════════════════════════════
#  CSV COLUMN MAPPING — flexible schema support
# ══════════════════════════════════════════════════════════════════════
# Maps internal column names → lists of accepted CSV header aliases (lowercase)
COLUMN_ALIASES = {
    'id':             ['id','emp_id','employee_id','staff_id','empid'],
    'name':           ['name','full_name','employee_name','emp_name'],
    'role':           ['role','job_title','title','position','designation'],
    'department':     ['department','dept','division','team','business_unit'],
    'experience':     ['experience','experience_years','years_experience','exp','exp_years','total_exp'],
    'skill_score':    ['skill_score','skill','skills','competency','skill_rating','skill_level'],
    'performance':    ['performance','performance_score','perf_score','perf','rating','performance_rating'],
    'salary':         ['salary','annual_salary','ctc','compensation','pay','base_salary','total_salary'],
    'tenure_years':   ['tenure_years','tenure','years_at_company','company_tenure','service_years','length_of_service'],
    'last_promotion': ['last_promotion','last_promotion_year','promotion_year','last_promoted'],
    'attendance_rate':['attendance_rate','attendance','attendance_pct','attendance_percentage'],
    'overtime_hours': ['overtime_hours','overtime','ot_hours','extra_hours','overtime_per_week'],
    'education':      ['education','education_level','qualification','degree','highest_qualification'],
    'certifications': ['certifications','certifications_count','certs','num_certifications','no_of_certifications'],
    'remote_ratio':   ['remote_ratio','remote','remote_work','wfh_pct','work_from_home','remote_percentage'],
}

DEFAULTS = {
    'id':             None,          # auto-generated if missing
    'name':           None,          # auto-generated if missing
    'role':           'General',
    'department':     'General',
    'experience':     3,
    'skill_score':    70,
    'performance':    75,
    'salary':         80000,
    'tenure_years':   2.0,
    'last_promotion': 2022,
    'attendance_rate':91,
    'overtime_hours': 6,
    'education':      'Bachelor',
    'certifications': 2,
    'remote_ratio':   50,
}

def map_columns(raw_df):
    """Rename CSV columns to internal names using alias matching."""
    col_map = {}
    raw_lower = {c.lower().strip().replace(' ','_'): c for c in raw_df.columns}
    for internal, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in raw_lower:
                col_map[raw_lower[alias]] = internal
                break
    return raw_df.rename(columns=col_map)

def enrich_dataset(df):
    """Fill missing columns with defaults and run all 4 models."""
    # Auto-generate id and name if missing
    if 'id' not in df.columns:
        df['id'] = [f'E{i:04d}' for i in range(1, len(df)+1)]
    if 'name' not in df.columns:
        df['name'] = [f'Employee {i}' for i in range(1, len(df)+1)]
    # Fill remaining missing columns
    for col, default in DEFAULTS.items():
        if col not in df.columns and default is not None:
            df[col] = default
    # Ensure numeric types
    for col in ['experience','skill_score','performance','salary','attendance_rate','overtime_hours','certifications']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(DEFAULTS[col])
    for col in ['tenure_years']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(DEFAULTS[col])
    for col in ['last_promotion','remote_ratio']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(DEFAULTS[col]).astype(int)
    # Clip to valid ranges
    df['skill_score']    = df['skill_score'].clip(0, 100)
    df['performance']    = df['performance'].clip(0, 100)
    df['attendance_rate']= df['attendance_rate'].clip(0, 100)
    df['overtime_hours'] = df['overtime_hours'].clip(0, 80)
    # Run models
    bench = salary_m.benchmark_batch(df)
    df['salary_benchmark'] = bench['benchmark_percentage'].values
    df['salary_status']    = bench['status'].values
    ch = churn_m.predict_batch(df)
    df['churn_probability'] = ch['probability'].values
    df['risk_level']        = ch['risk_level'].values
    sg = skill_m.analyze_batch(df)
    df['skill_gap']     = sg['gap_percentage'].values
    df['skill_gap_cat'] = sg['category'].values
    pr = promo_m.predict_batch(df)
    df['promotion_ready'] = pr['ready'].values
    df['promotion_score'] = pr['score'].values
    return df

# ══════════════════════════════════════════════════════════════════════
#  SIDEBAR — Upload + Navigation
# ══════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("""
    <div style="padding:18px 4px 14px">
      <div style="font-size:17px;font-weight:900;color:#38bdf8;letter-spacing:-.4px">🧠 Churn<br>Intelligence</div>
      <div style="font-size:10px;color:#475569;letter-spacing:2px;text-transform:uppercase;margin-top:2px">HR Analytics Platform</div>
    </div>
    <hr style="border-color:rgba(56,189,248,.1);margin:0 0 10px">
    <div style="font-size:10px;color:#475569;letter-spacing:2px;text-transform:uppercase;padding:6px 0 4px">📂 DATA SOURCE</div>
    """, unsafe_allow_html=True)

    uploaded_file = st.file_uploader(
        "Upload Employee CSV", type=["csv"],
        help="Upload a CSV file with employee data. Column names are matched automatically.",
        label_visibility="collapsed",
    )

    if uploaded_file is not None:
        try:
            raw = pd.read_csv(uploaded_file)
            mapped = map_columns(raw)
            df = enrich_dataset(mapped.copy())
            st.markdown(f'<div style="font-size:11px;color:#34d399;padding:6px 0">✅ Loaded <b>{len(df):,}</b> employees from CSV</div>', unsafe_allow_html=True)
        except Exception as e:
            st.error(f"Error reading CSV: {e}")
            df = None
    else:
        df = None

    st.markdown('<hr style="border-color:rgba(56,189,248,.1);margin:10px 0">', unsafe_allow_html=True)

    if df is not None:
        st.markdown('<div style="font-size:10px;color:#475569;letter-spacing:2px;text-transform:uppercase;padding:4px 0">ANALYTICS</div>', unsafe_allow_html=True)

        choice = st.radio("nav", [
            "📊 Overview", "🔬 Deep Analysis", "🤖 ML Models",
            "🎯 Predict Risk", "📈 Skill Analyzer",
            "🏆 Promotion Ready", "⚠️ Risk Monitor",
            "📋 AI Insights",
        ], label_visibility="collapsed")

        st.markdown('<hr style="border-color:rgba(56,189,248,.1);margin:10px 0"><div style="font-size:10px;color:#475569;letter-spacing:2px;text-transform:uppercase;padding-bottom:6px">FILTERS</div>', unsafe_allow_html=True)

        dept_filter = st.multiselect("Department", sorted(df['department'].unique()), placeholder="All departments")
        risk_filter = st.selectbox("Risk Level", ["All","High","Medium","Low"])

        filtered = df.copy()
        if dept_filter:  filtered = filtered[filtered['department'].isin(dept_filter)]
        if risk_filter != "All": filtered = filtered[filtered['risk_level'] == risk_filter]

        st.markdown('<hr style="border-color:rgba(56,189,248,.1);margin:10px 0">', unsafe_allow_html=True)
        st.markdown(f"""
        <div style="font-size:11px;color:#475569">
          <span style="display:block;margin-bottom:3px"><span class="sdot"></span>RF Model Active</span>
          <span style="display:block;padding-left:13px">Dataset: {len(df):,} employees</span>
          <span style="display:block;padding-left:13px">Overall churn: {df['churn_probability'].mean():.1%}</span>
          <span style="display:block;padding-left:13px">{len(df[df['risk_level']=='High'])} high-risk flagged</span>
        </div>""", unsafe_allow_html=True)
    else:
        choice = None
        filtered = None

# ══════════════════════════════════════════════════════════════════════
#  UPLOAD WELCOME SCREEN  — shown when no CSV is loaded
# ══════════════════════════════════════════════════════════════════════
if df is None:
    st.markdown("""
    <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:70vh;text-align:center;padding:40px 20px">
      <div style="font-size:64px;margin-bottom:20px">🧠</div>
      <div style="font-size:36px;font-weight:900;color:#e2e8f0;letter-spacing:-.5px;margin-bottom:8px">Churn Intelligence</div>
      <div style="font-size:16px;color:#64748b;margin-bottom:40px">HR Analytics Platform · Powered by Machine Learning</div>
      <div style="background:#111827;border:1px solid rgba(56,189,248,.2);border-radius:16px;padding:36px 48px;max-width:600px;width:100%">
        <div style="font-size:18px;font-weight:800;color:#38bdf8;margin-bottom:12px">📂 Upload Your Employee CSV</div>
        <div style="font-size:13px;color:#94a3b8;line-height:1.8;margin-bottom:24px">
          Upload a CSV file with your employee data using the uploader in the sidebar.<br>
          Column names are matched automatically — see accepted names below.
        </div>
        <div style="text-align:left;background:#0d1117;border-radius:10px;padding:18px 22px;font-size:12px;color:#64748b;line-height:2">
          <div style="color:#38bdf8;font-weight:700;margin-bottom:6px;font-size:11px;letter-spacing:1.5px;text-transform:uppercase">Accepted Column Names</div>
          <div><span style="color:#e2e8f0">name</span> · employee_name · full_name</div>
          <div><span style="color:#e2e8f0">role</span> · job_title · position · designation</div>
          <div><span style="color:#e2e8f0">department</span> · dept · division · team</div>
          <div><span style="color:#e2e8f0">salary</span> · annual_salary · ctc · compensation</div>
          <div><span style="color:#e2e8f0">performance</span> · performance_score · rating</div>
          <div><span style="color:#e2e8f0">skill_score</span> · skill · competency · skill_rating</div>
          <div><span style="color:#e2e8f0">tenure_years</span> · tenure · years_at_company</div>
          <div><span style="color:#e2e8f0">overtime_hours</span> · overtime · ot_hours</div>
          <div><span style="color:#e2e8f0">attendance_rate</span> · attendance · attendance_pct</div>
          <div><span style="color:#e2e8f0">experience</span> · experience_years · exp</div>
          <div><span style="color:#e2e8f0">last_promotion</span> · last_promotion_year</div>
          <div><span style="color:#e2e8f0">education</span> · qualification · degree</div>
          <div style="color:#475569;margin-top:8px;font-size:11px">Any missing columns are filled with sensible defaults automatically.</div>
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════
#  PAGE: OVERVIEW
# ══════════════════════════════════════════════════════════════════════
elif choice == "📊 Overview":
    st.markdown('<div class="sec-h">Executive Dashboard</div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-s">Real-time workforce attrition analytics & intelligence</div>', unsafe_allow_html=True)

    high_c = int((filtered['risk_level']=='High').sum())
    avg_r  = filtered['churn_probability'].mean()
    ot_pct = (filtered['overtime_hours'] > 10).mean() * 100

    c1,c2,c3,c4 = st.columns(4)
    for col,val,lbl,sub,acc in [
        (c1,f"{avg_r:.1%}","Avg Churn Risk",f"{high_c} high-risk employees",'#f87171'),
        (c2,f"${high_c*52000:,.0f}","Cost Risk (Est.)","~$52K avg replacement",'#fb923c'),
        (c3,f"{filtered['tenure_years'].mean():.1f}y","Avg Tenure",f"Avg exp: {filtered['experience'].mean():.0f} yrs",'#38bdf8'),
        (c4,f"{ot_pct:.1f}%","Overtime Rate",f"{int(ot_pct/100*len(filtered))} employees on OT",'#34d399'),
    ]:
        col.markdown(f'<div class="kpi" style="--acc:{acc}"><div class="kpi-lbl">{lbl}</div><div class="kpi-val" style="color:{acc}">{val}</div><div class="kpi-sub">{sub}</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    cl,cr = st.columns([3,2])
    with cl:
        dr = filtered.groupby('department')['churn_probability'].mean().sort_values()
        fig = go.Figure(go.Bar(x=dr.values*100, y=dr.index, orientation='h',
            marker=dict(color=['#f87171' if v>.55 else '#fb923c' if v>.35 else '#38bdf8' for v in dr.values]),
            text=[f"{v:.0%}" for v in dr.values], textposition='outside', textfont=dict(color='#94a3b8',size=11)))
        fig.update_layout(**DARK,title=dict(text="Avg Churn Risk by Department",font=dict(color='#e2e8f0',size=14)),
                          height=320,xaxis=dict(**AX,ticksuffix='%'),yaxis=dict(**AX))
        st.plotly_chart(dc(fig), use_container_width=True)
    with cr:
        rc = filtered['risk_level'].value_counts()
        clrs = {'High':'#f87171','Medium':'#fb923c','Low':'#34d399'}
        fig = go.Figure(go.Pie(labels=rc.index, values=rc.values, hole=.55,
            marker=dict(colors=[clrs.get(l,'#94a3b8') for l in rc.index]), textfont=dict(color='white')))
        fig.update_layout(**DARK,title=dict(text="Risk Distribution",font=dict(color='#e2e8f0',size=14)),height=320)
        st.plotly_chart(dc(fig), use_container_width=True)

    cl2,cr2 = st.columns(2)
    with cl2:
        sal = filtered.copy()
        sal['band'] = pd.cut(sal['salary'],bins=[0,70000,90000,110000,130000,200000],
                             labels=['<70K','70-90K','90-110K','110-130K','130K+'])
        br = sal.groupby('band',observed=True)['churn_probability'].mean()
        fig = go.Figure(go.Bar(x=br.index.astype(str), y=br.values*100,
            marker_color=['#f87171' if v>.5 else '#fb923c' if v>.35 else '#38bdf8' for v in br.values]))
        fig.update_layout(**DARK,title=dict(text="Salary Band vs Churn Risk",font=dict(color='#e2e8f0',size=14)),
                          height=280,xaxis=dict(**AX),yaxis=dict(**AX,ticksuffix='%'))
        st.plotly_chart(dc(fig), use_container_width=True)
    with cr2:
        tb = pd.cut(filtered['tenure_years'],bins=[0,1,2,3,5,10,20],labels=['<1','1-2','2-3','3-5','5-10','10+'])
        tr = filtered.groupby(tb,observed=True)['churn_probability'].mean()
        fig = go.Figure(go.Scatter(x=tr.index.astype(str), y=tr.values*100,
            mode='lines+markers', line=dict(color='#818cf8',width=3), marker=dict(size=8,color='#818cf8'),
            fill='tozeroy', fillcolor='rgba(129,140,248,.08)'))
        fig.update_layout(**DARK,title=dict(text="Tenure vs Churn Risk",font=dict(color='#e2e8f0',size=14)),
                          height=280,xaxis=dict(**AX),yaxis=dict(**AX,ticksuffix='%'))
        st.plotly_chart(dc(fig), use_container_width=True)

# ══════════════════════════════════════════════════════════════════════
#  PAGE: DEEP ANALYSIS
# ══════════════════════════════════════════════════════════════════════
elif choice == "🔬 Deep Analysis":
    st.markdown('<div class="sec-h">Deep Analysis</div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-s">Granular correlations, segment breakdowns & driver analysis</div>', unsafe_allow_html=True)

    t1,t2,t3 = st.tabs(["📊 Correlations","🧑‍🤝‍🧑 Segments","📉 Risk Drivers"])
    with t1:
        c1,c2 = st.columns(2)
        with c1:
            fig = px.scatter(filtered,x='salary',y='churn_probability',color='risk_level',size='overtime_hours',
                color_discrete_map={'High':'#f87171','Medium':'#fb923c','Low':'#34d399'},
                title='Salary vs Churn Risk',hover_data=['name','role'])
            fig.update_layout(**DARK,height=320,xaxis=dict(**AX),yaxis=dict(**AX,tickformat='.0%'))
            st.plotly_chart(dc(fig), use_container_width=True)
        with c2:
            fig = px.scatter(filtered,x='skill_score',y='performance',color='churn_probability',
                size='overtime_hours',color_continuous_scale='RdYlGn_r',
                title='Skill × Performance (colour = risk)',hover_data=['name','role'])
            fig.update_layout(**DARK,height=320,xaxis=dict(**AX),yaxis=dict(**AX))
            st.plotly_chart(dc(fig), use_container_width=True)
        num = ['skill_score','performance','salary','tenure_years','attendance_rate','overtime_hours','churn_probability']
        corr = filtered[num].corr()
        fig = px.imshow(corr,color_continuous_scale='RdBu_r',zmin=-1,zmax=1,
                        title='Feature Correlation Heatmap',text_auto='.2f')
        fig.update_layout(**DARK,height=400)
        st.plotly_chart(dc(fig), use_container_width=True)
    with t2:
        c1,c2 = st.columns(2)
        with c1:
            er = filtered.groupby('education')['churn_probability'].mean().sort_values()
            fig = go.Figure(go.Bar(x=er.values*100,y=er.index,orientation='h',marker_color='#818cf8',
                text=[f"{v:.0%}" for v in er.values],textposition='outside',textfont=dict(color='#94a3b8')))
            fig.update_layout(**DARK,title='Education vs Churn Risk',height=260,
                              xaxis=dict(**AX,ticksuffix='%'),yaxis=dict(**AX))
            st.plotly_chart(dc(fig), use_container_width=True)
        with c2:
            cr2 = filtered.groupby('certifications')['churn_probability'].mean()
            fig = go.Figure(go.Bar(x=cr2.index.astype(str),y=cr2.values*100,marker_color='#f472b6',
                text=[f"{v:.0%}" for v in cr2.values],textposition='outside',textfont=dict(color='#94a3b8')))
            fig.update_layout(**DARK,title='Certifications vs Churn Risk',height=260,
                              xaxis=dict(**AX),yaxis=dict(**AX,ticksuffix='%'))
            st.plotly_chart(dc(fig), use_container_width=True)
        ds = filtered.groupby('department').agg(count=('id','count'),
            avg_risk=('churn_probability','mean'),high_risk=('risk_level',lambda x:(x=='High').sum()),
            avg_skill=('skill_score','mean'),avg_tenure=('tenure_years','mean')).round(3).reset_index()
        ds['avg_risk'] = (ds['avg_risk']*100).round(1).astype(str)+'%'
        st.dataframe(ds, use_container_width=True, hide_index=True)
    with t3:
        imp = churn_m.get_feature_importance()
        fig = go.Figure(go.Bar(x=list(imp.values()),y=list(imp.keys()),orientation='h',
            marker=dict(color=list(imp.values()),colorscale='Blues',showscale=False),
            text=[f"{v:.0%}" for v in imp.values()],textposition='outside',textfont=dict(color='#94a3b8')))
        fig.update_layout(**DARK,title='Feature Importance (Model Weights)',height=340,
                          xaxis=dict(**AX,tickformat='.0%'),yaxis=dict(**AX))
        st.plotly_chart(dc(fig), use_container_width=True)

# ══════════════════════════════════════════════════════════════════════
#  PAGE: ML MODELS
# ══════════════════════════════════════════════════════════════════════
elif choice == "🤖 ML Models":
    st.markdown('<div class="sec-h">ML Model Lab</div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-s">Model performance metrics, ROC curves & training pipeline</div>', unsafe_allow_html=True)

    metas = [
        ("Random Forest", 87.4, 0.912, 84.2, 79.8, 81.9, '#38bdf8', True),
        ("XGBoost",       85.1, 0.893, 82.7, 77.3, 79.9, '#818cf8', False),
        ("Logistic Reg.", 78.3, 0.831, 76.1, 72.0, 74.0, '#f472b6', False),
        ("SVM",           81.9, 0.862, 79.4, 74.6, 76.9, '#fb923c', False),
    ]
    mc = st.columns(4)
    for col,(nm,acc,auc,pr,rec,f1,c,act) in zip(mc,metas):
        bd = f"2px solid {c}" if act else "1px solid rgba(56,189,248,.12)"
        rows = [("Accuracy",f"{acc}%"),("AUC-ROC",f"{auc}"),("Precision",f"{pr}%"),("Recall",f"{rec}%"),("F1",f"{f1}%")]
        inner = "".join([f'<div style="display:flex;justify-content:space-between;font-size:10px;color:#64748b;padding:2px 0"><span>{k}</span><span style="color:{c};font-weight:700">{v}</span></div>' for k,v in rows])
        badge = f'<div style="margin-top:8px;font-size:9px;letter-spacing:1px;color:{c};border:1px solid {c};border-radius:4px;padding:2px 8px;display:inline-block">ACTIVE</div>' if act else ''
        col.markdown(f'<div style="background:#111827;border:{bd};border-radius:12px;padding:16px;text-align:center"><div style="font-size:12px;font-weight:800;color:#e2e8f0;margin-bottom:10px">{nm}</div>{inner}{badge}</div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    cl,cr = st.columns(2)
    with cl:
        fpr = np.linspace(0,1,120)
        fig = go.Figure()
        for nm,c,sd,pw in [("Random Forest (0.912)","#38bdf8",1,.32),("XGBoost (0.893)","#818cf8",2,.38),("Logistic Reg. (0.831)","#f472b6",3,.58)]:
            tpr = np.clip(fpr**pw + np.random.RandomState(sd).normal(0,.012,120),0,1)
            fig.add_trace(go.Scatter(x=fpr,y=tpr,name=nm,line=dict(color=c,width=2)))
        fig.add_trace(go.Scatter(x=[0,1],y=[0,1],showlegend=False,line=dict(color='#475569',dash='dot')))
        fig.update_layout(**DARK,title=dict(text='ROC Curves',font=dict(color='#e2e8f0',size=14)),height=320,
                          xaxis=dict(**AX,title='FPR'),yaxis=dict(**AX,title='TPR'))
        st.plotly_chart(dc(fig), use_container_width=True)
    with cr:
        n_tot = len(df)
        cm = np.array([[int(n_tot*0.58),int(n_tot*0.09)],[int(n_tot*0.1),int(n_tot*0.23)]])
        fig = px.imshow(cm,text_auto=True,color_continuous_scale='Blues',
                        x=['Pred Stay','Pred Leave'],y=['Act Stay','Act Leave'],
                        title='Confusion Matrix — Random Forest')
        fig.update_layout(**DARK,height=320)
        st.plotly_chart(dc(fig), use_container_width=True)

    st.markdown('<div class="card"><b>Training Pipeline</b><br><br>', unsafe_allow_html=True)
    steps=[("📊","Raw Data",f"{len(df)} rows"),("🔧","Feature Eng.","12 features"),
           ("⚖️","SMOTE","Balanced"),("📐","Train/Test","80/20"),
           ("🤖","RF Model","Best AUC"),("🧠","SHAP","Explainability"),("💡","Insights","Actions")]
    pc = st.columns(len(steps)*2-1)
    for i,(ic,tt,sub) in enumerate(steps):
        hi = i in [4,6]; bg = '#38bdf8' if i==4 else '#34d399' if i==6 else '#131920'
        tc = '#000' if hi else '#e2e8f0'; sc = '#000' if hi else '#64748b'
        bd = f"1px solid {'#38bdf8' if i==4 else '#34d399' if i==6 else 'rgba(56,189,248,.18)'}"
        pc[i*2].markdown(f'<div style="background:{bg};border:{bd};border-radius:8px;padding:10px 8px;text-align:center;font-size:11px"><div style="font-size:18px">{ic}</div><div style="font-weight:800;color:{tc}">{tt}</div><div style="color:{sc};font-size:10px">{sub}</div></div>', unsafe_allow_html=True)
        if i < len(steps)-1: pc[i*2+1].markdown('<div style="text-align:center;color:#38bdf8;font-size:22px;padding-top:18px">→</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

    cl2,cr2 = st.columns(2)
    with cl2:
        imp = churn_m.get_feature_importance()
        fig = go.Figure(go.Bar(x=list(imp.values()),y=list(imp.keys()),orientation='h',
            marker=dict(color=list(imp.values()),colorscale='Blues',showscale=False),
            text=[f"{v:.0%}" for v in imp.values()],textposition='outside',textfont=dict(color='#94a3b8')))
        fig.update_layout(**DARK,title='Feature Importance',height=300,
                          xaxis=dict(**AX,tickformat='.0%'),yaxis=dict(**AX))
        st.plotly_chart(dc(fig), use_container_width=True)
    with cr2:
        epochs=list(range(1,51)); np.random.seed(7)
        tl=[0.72*np.exp(-0.06*i)+np.random.uniform(0,.02) for i in epochs]
        vl=[0.78*np.exp(-0.05*i)+np.random.uniform(0,.03) for i in epochs]
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=epochs,y=tl,name='Train Loss',line=dict(color='#38bdf8',width=2)))
        fig.add_trace(go.Scatter(x=epochs,y=vl,name='Val Loss',line=dict(color='#f87171',width=2,dash='dash')))
        fig.update_layout(**DARK,title='Training Loss Curve',height=300,
                          xaxis=dict(**AX,title='Epoch'),yaxis=dict(**AX,title='Loss'))
        st.plotly_chart(dc(fig), use_container_width=True)

# ══════════════════════════════════════════════════════════════════════
#  PAGE: PREDICT RISK
# ══════════════════════════════════════════════════════════════════════
elif choice == "🎯 Predict Risk":
    st.markdown("""
    <div style="margin-bottom:10px">
      <span style="background:rgba(56,189,248,.15);border:1px solid rgba(56,189,248,.3);
                   color:#38bdf8;font-size:11px;font-weight:800;letter-spacing:1px;
                   padding:4px 14px;border-radius:20px">AI Prediction</span>
    </div>
    <div style="font-size:30px;font-weight:900;color:#e2e8f0;letter-spacing:-.5px;margin-bottom:4px">
      Predict Employee Churn Risk
    </div>
    <div style="font-size:13px;color:#64748b;margin-bottom:20px">
      Adjust sliders to get instant churn probability from the trained model
    </div>""", unsafe_allow_html=True)

    col_l, col_r = st.columns([3,2], gap="large")
    with col_l:
        st.markdown('<div class="profile-box"><div class="profile-box-title">Employee Profile</div>', unsafe_allow_html=True)
        r1a,r1b = st.columns(2); r2a,r2b = st.columns(2)
        r3a,r3b = st.columns(2); r4a,r4b = st.columns(2)
        r5a,r5b = st.columns(2); r6a,r6b = st.columns(2)
        with r1a:
            st.markdown('<div class="slider-lbl">SATISFACTION SCORE</div>', unsafe_allow_html=True)
            satisfaction = st.slider("sat",0.0,1.0,0.50,0.05,format="%.2f",label_visibility="collapsed")
        with r1b:
            st.markdown('<div class="slider-lbl">PERFORMANCE RATING</div>', unsafe_allow_html=True)
            performance  = st.slider("perf",1.0,5.0,3.5,0.1,format="%.1f",label_visibility="collapsed")
        with r2a:
            st.markdown('<div class="slider-lbl">MONTHLY HOURS</div>', unsafe_allow_html=True)
            monthly_hrs  = st.slider("hrs",100,320,165,5,format="%dh",label_visibility="collapsed")
        with r2b:
            st.markdown('<div class="slider-lbl">LAST PROMOTION (YRS AGO)</div>', unsafe_allow_html=True)
            last_promo   = st.slider("promo",0.0,10.0,2.0,0.5,format="%.1fy",label_visibility="collapsed")
        with r3a:
            st.markdown('<div class="slider-lbl">TENURE (YEARS)</div>', unsafe_allow_html=True)
            tenure       = st.slider("ten",0.0,20.0,3.0,0.5,format="%.1fy",label_visibility="collapsed")
        with r3b:
            st.markdown('<div class="slider-lbl">NUMBER OF PROJECTS</div>', unsafe_allow_html=True)
            num_proj     = st.slider("proj",1,10,3,label_visibility="collapsed")
        with r4a:
            st.markdown('<div class="slider-lbl">ANNUAL SALARY (₹K)</div>', unsafe_allow_html=True)
            salary_k     = st.slider("sal",30,300,70,5,format="₹%dK",label_visibility="collapsed")
        with r4b:
            st.markdown('<div class="slider-lbl">DISTANCE TO OFFICE (KM)</div>', unsafe_allow_html=True)
            distance     = st.slider("dist",0,100,12,format="%dkm",label_visibility="collapsed")
        with r5a:
            st.markdown('<div class="slider-lbl">OVERTIME</div>', unsafe_allow_html=True)
            overtime_sel = st.selectbox("ot",["No overtime","Works overtime"],label_visibility="collapsed")
        with r5b:
            st.markdown('<div class="slider-lbl">WORK ACCIDENT</div>', unsafe_allow_html=True)
            accident_sel = st.selectbox("acc",["No accident","Had accident"],label_visibility="collapsed")
        with r6a:
            st.markdown('<div class="slider-lbl">REMOTE RATIO</div>', unsafe_allow_html=True)
            remote       = st.slider("rem",0,100,50,5,format="%d%%",label_visibility="collapsed")
        with r6b:
            st.markdown('<div class="slider-lbl">SALARY HIKE %</div>', unsafe_allow_html=True)
            hike         = st.slider("hike",0,25,8,format="%d%%",label_visibility="collapsed")
        st.markdown('</div>', unsafe_allow_html=True)

    emp_dict = {
        'skill_score':      satisfaction * 100,
        'performance':      performance / 5 * 100,
        'salary_benchmark': min(130, salary_k / 80 * 100),
        'overtime_hours':   max(0, (monthly_hrs-160)/4) + (10 if overtime_sel=="Works overtime" else 0),
        'attendance_rate':  93 - (8 if accident_sel=="Had accident" else 0),
        'tenure_years':     tenure,
        'last_promotion':   int(2025 - last_promo),
    }
    prob = churn_m.predict_churn(emp_dict)
    pct  = round(prob * 100)
    if pct>=65:   r_col,r_icon='#f87171','⚠️ High Risk — Needs Immediate Action'
    elif pct>=35: r_col,r_icon='#fb923c','⚡ Medium Risk — Monitor Closely'
    else:         r_col,r_icon='#34d399','✓ Low Risk — Likely to Stay'
    factors = churn_m.explain_factors(emp_dict)
    actions = churn_m.recommend_actions(emp_dict)

    signals = [
        ('Very low satisfaction',      satisfaction < 0.30,                             'H'),
        ('Overwork (hours + OT)',      monthly_hrs > 210 or overtime_sel=="Works overtime",'H'),
        ('Works overtime',             overtime_sel=="Works overtime",                    'M'),
        ('No promotion 2+ yrs',        last_promo >= 2,                                  'M'),
        ('Long commute (>30 km)',       distance > 30,                                    'L'),
        ('Work accident history',      accident_sel=="Had accident",                      'M'),
        ('Too many projects (>6)',     num_proj > 6,                                      'M'),
        ('Low salary hike (<5%)',       hike < 5,                                         'M'),
        ('Low remote flexibility',     remote < 25,                                       'L'),
        ('Short tenure (<1.5 yrs)',    tenure < 1.5,                                      'H'),
    ]
    sev_c={'H':'#f87171','M':'#fb923c','L':'#facc15'}
    sev_l={'H':'HIGH','M':'MED','L':'LOW'}

    with col_r:
        badge_bg = ('rgba(248,113,113,.15)' if pct>=65 else 'rgba(251,146,60,.15)' if pct>=35 else 'rgba(52,211,153,.15)')
        st.markdown(f"""
        <div class="gauge-card">
          <div style="font-size:10px;letter-spacing:2.5px;text-transform:uppercase;color:#64748b;font-weight:700;margin-bottom:8px">CHURN PROBABILITY</div>
          <div class="gauge-pct" style="color:{r_col}">{pct}<span style="font-size:40px">%</span></div>
          <div style="margin-top:12px">
            <span class="gauge-badge" style="background:{badge_bg};border:1px solid {r_col}55;color:{r_col}">{r_icon}</span>
          </div>
        </div>""", unsafe_allow_html=True)

        fig = go.Figure(go.Indicator(
            mode="gauge+number", value=pct,
            number=dict(suffix="%",font=dict(size=1,color='rgba(0,0,0,0)')),
            gauge=dict(
                axis=dict(range=[0,100],tickvals=[0,25,50,75,100],ticktext=['0','25','50','75','100'],
                          tickwidth=1,tickcolor='#334155',tickfont=dict(color='#475569',size=11)),
                bar=dict(color=r_col,thickness=0.25), bgcolor='rgba(0,0,0,0)', borderwidth=0,
                steps=[dict(range=[0,35],color='rgba(52,211,153,.10)'),
                       dict(range=[35,65],color='rgba(251,146,60,.10)'),
                       dict(range=[65,100],color='rgba(248,113,113,.10)')],
                threshold=dict(line=dict(color=r_col,width=4),thickness=0.85,value=pct),
            ), domain=dict(x=[0,1],y=[0,1])))
        fig.update_layout(paper_bgcolor='rgba(0,0,0,0)',font=dict(color='#94a3b8'),
            margin=dict(t=10,b=5,l=20,r=20),height=200,
            annotations=[
                dict(x=0.18,y=0.08,xref='paper',yref='paper',text='<b style="color:#475569;font-size:11px">LOW</b>',showarrow=False),
                dict(x=0.82,y=0.08,xref='paper',yref='paper',text='<b style="color:#475569;font-size:11px">HIGH</b>',showarrow=False)])
        st.plotly_chart(fig, use_container_width=True)

        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<div style="font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#64748b;font-weight:700;margin-bottom:10px">RISK SIGNAL CHECKLIST</div>', unsafe_allow_html=True)
        for label,active,sev in signals:
            dc_ = sev_c[sev] if active else '#1e293b'
            tc  = '#e2e8f0' if active else '#475569'
            bdg = f'<span style="margin-left:auto;font-size:9px;font-weight:800;color:{sev_c[sev]};background:{sev_c[sev]}22;border:1px solid {sev_c[sev]}44;padding:1px 7px;border-radius:8px">{sev_l[sev]}</span>' if active else ''
            st.markdown(f'<div class="sig-row" style="color:{tc}"><span class="sig-dot" style="background:{dc_};border:1px solid {dc_}"></span><span style="flex:1">{label}</span>{bdg}</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    bf,ba = st.columns(2)
    with bf:
        st.markdown('<div class="card"><div style="font-size:14px;font-weight:800;color:#e2e8f0;margin-bottom:14px">⚡ Top Risk Factors</div>', unsafe_allow_html=True)
        if factors:
            for fname,fval in factors.items():
                bw=int(fval*100); fc='#f87171' if fval>.35 else '#fb923c' if fval>.18 else '#38bdf8'
                st.markdown(f'<div style="margin-bottom:13px"><div style="display:flex;justify-content:space-between;font-size:12px;color:#94a3b8;margin-bottom:5px"><span>{fname}</span><span style="color:{fc};font-weight:700">{fval:.0%} impact</span></div><div class="fbar-wrap"><div class="fbar-fill" style="width:{bw}%;background:{fc}"></div></div></div>', unsafe_allow_html=True)
        else:
            st.markdown('<div style="color:#34d399;font-size:13px;text-align:center;padding:16px">✅ No significant risk factors detected</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
    with ba:
        st.markdown('<div class="card"><div style="font-size:14px;font-weight:800;color:#e2e8f0;margin-bottom:14px">🤖 AI Recommendations</div>', unsafe_allow_html=True)
        for action in actions:
            st.markdown(f'<div style="background:#131920;border:1px solid rgba(56,189,248,.10);border-radius:8px;padding:11px 13px;margin-bottom:8px;font-size:12px;color:#94a3b8;line-height:1.55">{action}</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════
#  PAGE: SKILL ANALYZER
# ══════════════════════════════════════════════════════════════════════
elif choice == "📈 Skill Analyzer":
    st.markdown('<div class="sec-h">Skill Gap Analyzer</div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-s">Role-specific skill assessments, gap analysis & personalised learning paths</div>', unsafe_allow_html=True)

    crit_n=(filtered['skill_gap_cat']=='Critical').sum()
    mod_n =(filtered['skill_gap_cat']=='Moderate').sum()
    low_n =(filtered['skill_gap_cat']=='Low').sum()
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("🔴 Critical Gaps",  int(crit_n), delta=f"{crit_n/max(len(filtered),1):.0%} of workforce")
    c2.metric("🟠 Moderate Gaps",  int(mod_n))
    c3.metric("🟢 Low Gaps",       int(low_n))
    c4.metric("📊 Avg Skill Score", f"{filtered['skill_score'].mean():.0f}/100")

    st.markdown("<br>", unsafe_allow_html=True)
    c1,c2 = st.columns(2)
    with c1:
        ds = filtered.groupby('department')['skill_score'].mean().sort_values()
        fig = go.Figure(go.Bar(x=ds.values,y=ds.index,orientation='h',
            marker=dict(color=ds.values,colorscale='Blues',showscale=False),
            text=[f"{v:.0f}" for v in ds.values],textposition='outside',textfont=dict(color='#94a3b8')))
        fig.update_layout(**DARK,title='Avg Skill Score by Department',height=300,
                          xaxis=dict(**AX,range=[0,115]),yaxis=dict(**AX))
        st.plotly_chart(dc(fig), use_container_width=True)
    with c2:
        gc = filtered['skill_gap_cat'].value_counts()
        clrs2={'Critical':'#f87171','Moderate':'#fb923c','Low':'#34d399'}
        fig = go.Figure(go.Pie(labels=gc.index,values=gc.values,hole=.5,
            marker=dict(colors=[clrs2.get(l,'#94a3b8') for l in gc.index])))
        fig.update_layout(**DARK,title='Skill Gap Category Split',height=300)
        st.plotly_chart(dc(fig), use_container_width=True)

    st.markdown("### 🔍 Individual Skill Drill-Down")
    all_names = sorted(filtered['name'].unique().tolist())
    if not all_names:
        st.warning("No employees match current filters.")
    else:
        emp_sel  = st.selectbox("Select Employee", all_names)
        mask     = filtered['name'] == emp_sel
        emp_row  = filtered[mask].iloc[0] if mask.any() else filtered.iloc[0]
        gap_data = skill_m.analyze_skill_gap(emp_row.to_dict())
        bd       = gap_data['skill_breakdown']
        skills   = list(bd.keys())
        scores   = list(bd.values())

        cl,cr = st.columns([3,2])
        with cl:
            bclrs=['#f87171' if s<60 else '#fb923c' if s<75 else '#34d399' for s in scores]
            fig = go.Figure(go.Bar(x=scores,y=skills,orientation='h',marker_color=bclrs,
                text=[str(s) for s in scores],textposition='outside',textfont=dict(color='#94a3b8')))
            fig.add_vline(x=75,line_dash='dash',line_color='#818cf8',
                          annotation_text="Target 75",annotation_font_color='#818cf8')
            fig.update_layout(**DARK,title=f"Skill Breakdown — {emp_sel}",height=280,
                              xaxis=dict(**AX,range=[0,115]),yaxis=dict(**AX))
            st.plotly_chart(dc(fig), use_container_width=True)

            fig2 = go.Figure(go.Scatterpolar(
                r=scores+[scores[0]],theta=skills+[skills[0]],fill='toself',
                fillcolor='rgba(56,189,248,.10)',line=dict(color='#38bdf8',width=2),
                marker=dict(size=7,color='#38bdf8')))
            fig2.update_layout(**DARK,title=f"Skill Radar",
                polar=dict(radialaxis=dict(visible=True,range=[0,100],color='#475569',
                                          gridcolor='rgba(56,189,248,.10)'),
                           angularaxis=dict(color='#64748b',gridcolor='rgba(56,189,248,.08)'),
                           bgcolor='rgba(0,0,0,0)'),height=300)
            st.plotly_chart(dc(fig2), use_container_width=True)

        with cr:
            sc_v=int(emp_row['skill_score']); cc_='#f87171' if sc_v<60 else '#fb923c' if sc_v<75 else '#34d399'
            cat_c='#f87171' if gap_data['category']=='Critical' else '#fb923c' if gap_data['category']=='Moderate' else '#34d399'
            st.markdown(f"""
            <div class="card">
              <div style="font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#38bdf8;font-weight:700;margin-bottom:4px">SKILL ASSESSMENT</div>
              <div style="font-size:30px;font-weight:900;color:#e2e8f0">{sc_v}<span style="font-size:14px;color:#64748b">/100</span></div>
              <div style="font-size:12px;color:{cat_c};margin:4px 0 12px">{gap_data['category']} Gap · {gap_data['gap_percentage']:.0f}% to target</div>
              <div class="prog-wrap"><div class="prog-fill" style="width:{sc_v}%;background:{cc_}"></div></div>
              <div style="display:flex;justify-content:space-between;font-size:10px;color:#475569;margin-top:4px"><span>0</span><span>Target: 85</span><span>100</span></div>
              <div style="margin-top:14px;font-size:12px;color:#94a3b8">
                <b>Dept:</b> {emp_row['department']} &nbsp;·&nbsp; <b>Exp:</b> {emp_row['experience']} yrs &nbsp;·&nbsp; <b>Perf:</b> {emp_row['performance']}/100
              </div>
            </div>""", unsafe_allow_html=True)

            lp = skill_m.get_learning_path(emp_row.to_dict())
            st.markdown('<div class="card"><div style="font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#38bdf8;font-weight:700;margin-bottom:12px">📚 LEARNING PATH</div>', unsafe_allow_html=True)
            for i,course in enumerate(lp,1):
                st.markdown(f'<div style="display:flex;gap:12px;align-items:center;padding:9px 0;border-bottom:1px solid rgba(56,189,248,.06)"><span style="width:24px;height:24px;border-radius:50%;background:rgba(56,189,248,.15);border:1px solid rgba(56,189,248,.3);color:#38bdf8;font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;line-height:24px;text-align:center">{i}</span><span style="font-size:13px;color:#e2e8f0">{course}</span></div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

            ret = churn_m.recommend_actions(emp_row.to_dict())
            st.markdown('<div class="card"><div style="font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#818cf8;font-weight:700;margin-bottom:10px">🎯 RETENTION ACTIONS</div>', unsafe_allow_html=True)
            for a in ret:
                st.markdown(f'<div style="font-size:12px;color:#94a3b8;padding:7px 0;border-bottom:1px solid rgba(56,189,248,.06)">{a}</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

        crit_df = filtered[filtered['skill_gap_cat']=='Critical'].sort_values('skill_gap',ascending=False)
        if not crit_df.empty:
            st.markdown(f"### 🚨 {len(crit_df)} Employees with Critical Skill Gaps (>30%)")
            for _,emp in crit_df.head(5).iterrows():
                with st.expander(f"🎓 {emp['name']} — {emp['role']}  |  Gap: {emp['skill_gap']:.0f}%"):
                    ea,eb = st.columns(2)
                    with ea:
                        recs=skill_m.get_learning_path(emp.to_dict())
                        st.markdown("**Recommended learning path:**")
                        for r in recs: st.write(f"- {r}")
                    with eb:
                        sw=int(emp['skill_score']); pc_='#f87171' if sw<60 else '#fb923c' if sw<75 else '#34d399'
                        st.markdown(f'<div class="prog-wrap"><div class="prog-fill" style="width:{sw}%;background:{pc_}"></div></div>', unsafe_allow_html=True)
                        st.caption(f"Current: {sw}/100  |  Target: 85+  |  Dept: {emp['department']}")
        else:
            st.success("🎉 No critical skill gaps!")

# ══════════════════════════════════════════════════════════════════════
#  PAGE: PROMOTION READY
# ══════════════════════════════════════════════════════════════════════
elif choice == "🏆 Promotion Ready":
    st.markdown('<div class="sec-h">Promotion Intelligence</div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-s">Data-driven recommendations & impact analysis</div>', unsafe_allow_html=True)
    ready_df=filtered[filtered['promotion_ready']]; not_r=filtered[~filtered['promotion_ready']]
    c1,c2,c3=st.columns(3)
    c1.metric("✅ Promotion Ready",   len(ready_df), delta="High potential")
    c2.metric("📚 Needs Development", len(not_r))
    c3.metric("🌟 Avg Promo Score",   f"{filtered['promotion_score'].mean():.1f}/100")
    st.markdown("<br>",unsafe_allow_html=True)
    if not ready_df.empty:
        top=ready_df.sort_values('promotion_score',ascending=False).head(10)
        fig=go.Figure(go.Bar(x=top['promotion_score'],y=top['name'],orientation='h',
            marker=dict(color=top['promotion_score'],colorscale='Viridis',showscale=False),
            text=[f"{s:.0f}" for s in top['promotion_score']],textposition='outside',textfont=dict(color='#94a3b8')))
        fig.update_layout(**DARK,title='Top Promotion Candidates',height=320,
                          xaxis=dict(**AX,range=[0,115]),yaxis=dict(**AX))
        st.plotly_chart(dc(fig),use_container_width=True)
        for _,emp in top.head(3).iterrows():
            with st.expander(f"🚀 {emp['name']} — {emp['role']}  |  Score: {emp['promotion_score']:.0f}"):
                impact=promo_m.calculate_impact(emp.to_dict())
                ca,cb,cc=st.columns(3)
                ca.metric("Retention Boost",f"+{impact['retention_boost']:.0f}%")
                cb.metric("Recommended Raise",impact['recommended_increase'])
                cc.metric("Timeline",impact['timeline'])
    else:
        st.info("No employees are currently promotion-ready.")
    c1,c2=st.columns(2)
    with c1:
        fig=px.scatter(filtered,x='promotion_score',y='churn_probability',color='promotion_ready',
            color_discrete_map={True:'#34d399',False:'#f87171'},hover_data=['name','role'],
            title='Promotion Score vs Churn Risk')
        fig.update_layout(**DARK,height=300,xaxis=dict(**AX),yaxis=dict(**AX,tickformat='.0%'))
        st.plotly_chart(dc(fig),use_container_width=True)
    with c2:
        dp=filtered.groupby('department')['promotion_ready'].mean()*100
        fig=go.Figure(go.Bar(x=dp.values,y=dp.index,orientation='h',
            marker=dict(color=dp.values,colorscale='Greens',showscale=False),
            text=[f"{v:.0f}%" for v in dp.values],textposition='outside',textfont=dict(color='#94a3b8')))
        fig.update_layout(**DARK,title='% Promotion-Ready by Department',height=300,
                          xaxis=dict(**AX,range=[0,120]),yaxis=dict(**AX))
        st.plotly_chart(dc(fig),use_container_width=True)

# ══════════════════════════════════════════════════════════════════════
#  PAGE: RISK MONITOR
# ══════════════════════════════════════════════════════════════════════
elif choice == "⚠️ Risk Monitor":
    st.markdown('<div class="sec-h">Real-time Risk Monitor</div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-s">Live employee risk tracking & intervention board</div>', unsafe_allow_html=True)
    high_df=filtered[filtered['risk_level']=='High']; med_df=filtered[filtered['risk_level']=='Medium']; low_df=filtered[filtered['risk_level']=='Low']
    c1,c2,c3,c4=st.columns(4)
    c1.metric("🔴 High Risk",len(high_df),delta="Immediate action")
    c2.metric("🟠 Medium Risk",len(med_df))
    c3.metric("🟢 Low Risk",len(low_df))
    c4.metric("💰 Est. Cost",f"${len(high_df)*52000:,}",delta="if no action")
    cl,cr=st.columns([2,3])
    with cl:
        rc=filtered['risk_level'].value_counts()
        clrs3={'High':'#f87171','Medium':'#fb923c','Low':'#34d399'}
        fig=go.Figure(go.Pie(labels=rc.index,values=rc.values,hole=.55,
            marker=dict(colors=[clrs3.get(l,'#94a3b8') for l in rc.index])))
        fig.update_layout(**DARK,title='Risk Distribution',height=280)
        st.plotly_chart(dc(fig),use_container_width=True)
    with cr:
        fig=px.scatter(filtered,x='tenure_years',y='churn_probability',color='risk_level',size='overtime_hours',
            color_discrete_map={'High':'#f87171','Medium':'#fb923c','Low':'#34d399'},
            hover_data=['name','role','department'],title='Tenure vs Churn Risk')
        fig.update_layout(**DARK,height=280,xaxis=dict(**AX),yaxis=dict(**AX,tickformat='.0%'))
        st.plotly_chart(dc(fig),use_container_width=True)
    st.markdown("### 🔴 High-Risk Action Board")
    if not high_df.empty:
        for _,emp in high_df.head(20).iterrows():
            ca,cb,cc,cd,ce=st.columns([3,1,1,1,1])
            ca.markdown(f"**{emp['name']}** — {emp['role']} · {emp['department']}")
            cb.markdown(f"<span style='color:#f87171;font-weight:800'>{emp['churn_probability']:.0%}</span>",unsafe_allow_html=True)
            cc.markdown(f"Gap: **{emp['skill_gap']:.0f}%**")
            cd.markdown(f"OT: **{emp['overtime_hours']}h**")
            if ce.button("Plan",key=f"p_{emp['id']}"):
                st.info("  \n".join(churn_m.recommend_actions(emp.to_dict())))
            st.markdown('<hr style="border-color:rgba(56,189,248,.07);margin:3px 0">',unsafe_allow_html=True)
    else:
        st.success("🎉 No high-risk employees — retention strategy is working!")

# ══════════════════════════════════════════════════════════════════════
#  PAGE: AI INSIGHTS
# ══════════════════════════════════════════════════════════════════════
elif choice == "📋 AI Insights":
    st.markdown('<div class="sec-h">AI-Powered Strategic Insights</div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-s">6-month projections, executive recommendations & export</div>', unsafe_allow_html=True)
    ins=churn_m.strategic_insights(filtered)
    c1,c2,c3=st.columns(3)
    c1.metric("📊 Avg Churn Risk",f"{ins['avg_risk']:.1%}")
    c2.metric("⚠️ High-Risk Count",ins['high_risk_count'])
    c3.metric("💰 Est. Annual Loss",f"${ins['cost_estimate']:,}")
    urg_c={'High':'#f87171','Medium':'#fb923c','Low':'#34d399'}[ins['urgency']]
    st.markdown(f'<div style="background:{urg_c}14;border:1px solid {urg_c}40;border-radius:10px;padding:14px 18px;margin:14px 0"><span style="color:{urg_c};font-weight:800;font-size:13px">{"🔴" if ins["urgency"]=="High" else "🟠" if ins["urgency"]=="Medium" else "🟢"} Urgency: {ins["urgency"]}</span><div style="margin-top:10px">{"".join([f"<div style=\'font-size:12px;color:#94a3b8;padding:3px 0\'>• {r}</div>" for r in ins["recommendations"]])}</div></div>', unsafe_allow_html=True)
    future=churn_m.future_trends(filtered,months=6)
    ml=[f"Month {m}" for m in future['months']]
    fig=go.Figure()
    fig.add_trace(go.Scatter(x=ml,y=future['expected'],name='Current Trajectory',line=dict(color='#38bdf8',width=3)))
    fig.add_trace(go.Scatter(x=ml,y=future['optimistic'],name='With Interventions',line=dict(color='#34d399',width=2,dash='dash')))
    fig.add_trace(go.Scatter(x=ml,y=future['pessimistic'],name='No Action',line=dict(color='#f87171',width=2,dash='dash')))
    fig.add_hline(y=.30,line_dash='dot',line_color='#64748b',annotation_text='Target 30%',annotation_font_color='#64748b')
    fig.update_layout(**DARK,title=dict(text='6-Month Churn Risk Projection',font=dict(color='#e2e8f0',size=14)),height=340,xaxis=dict(**AX),yaxis=dict(**AX,tickformat='.0%',title='Risk'))
    st.plotly_chart(dc(fig),use_container_width=True)
    c1,c2=st.columns(2)
    with c1:
        dt=filtered.groupby('department').agg(count=('id','count'),risk_pct=('churn_probability',lambda x:x.mean()*100)).reset_index()
        fig=px.treemap(dt,path=['department'],values='count',color='risk_pct',color_continuous_scale='RdYlGn_r',title='Department Risk Treemap')
        fig.update_layout(**DARK,height=300)
        st.plotly_chart(dc(fig),use_container_width=True)
    with c2:
        imp=churn_m.get_feature_importance()
        fig=go.Figure(go.Pie(labels=list(imp.keys()),values=list(imp.values()),hole=.5,marker=dict(colors=CLR)))
        fig.update_layout(**DARK,title='Risk Driver Composition',height=300)
        st.plotly_chart(dc(fig),use_container_width=True)
    st.markdown("### 📥 Export Report")
    if st.button("Generate JSON Report"):
        report={'generated_at':datetime.now().isoformat(),'total_employees':len(filtered),
                'insights':{k:(float(v) if isinstance(v,(np.floating,float)) else v) for k,v in ins.items()},
                'high_risk_employees':filtered[filtered['risk_level']=='High'][['name','role','department','churn_probability']].to_dict(orient='records')}
        b64=base64.b64encode(json.dumps(report,indent=2,default=str).encode()).decode()
        st.markdown(f'<a href="data:application/json;base64,{b64}" download="churn_report.json">📥 Download JSON Report</a>',unsafe_allow_html=True)
        st.success("Report ready!")